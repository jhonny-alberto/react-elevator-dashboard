import { all, takeLatest, put, call } from 'redux-saga/effects'

import actions from './action'


export function* createLog({ msg, data }) {
  let rw_key = SERVICES.LOGGER_KEY
  let uri = 'noformat/logs/' + SERVICES.LOGGER_OWNER_KEY
  let body = {
    message: msg,
    data,
  }

  console.log('Logging   ', msg, data)

  let url = 'https://webhook.logentries.com/' + uri
  let headers = {
    'Postman-Token': rw_key,
    'Content-Type': 'application/json',
  }

  let res = yield call(() =>
    fetch(url, {
      body: JSON.stringify(body),
      headers: headers,
      method: 'POST',
    })
  )
}

export default function* rootSaga() {
  yield all([
    // yield takeLatest(actions.CREATE_LOG, createLog)
  ])
}
