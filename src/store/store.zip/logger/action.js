const actions = {
	CREATE_LOG: 'CREATE_LOG',

	createLog: (msg, data, log_level = 1) => (dispatch, getState) => {
		dispatch({ type: actions.CREATE_LOG, msg, data, log_level });
	}
}

export default actions;
