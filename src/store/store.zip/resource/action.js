const actions = {
	LOAD_RESOURCES: 'LOAD_RESOURCES',
	SET_RESOURCES: 'SET_RESOURCES',

	loadResources: () => (dispatch, getState) => {
		dispatch({ type: actions.LOAD_RESOURCES }); 
	}
}

export default actions;
