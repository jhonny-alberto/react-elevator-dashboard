import { all, takeLatest, put, call } from 'redux-saga/effects'
import actions from './action'
import appActions from '../app/action'
import loggerActions from '../logger/action'
import { getLanguage } from '../../services/api'

export function* loadResources() {
  yield put({ type: appActions.API_CALL_START })
  let language = yield localStorage.getItem('language')
  console.log('loadResources with language: ' + language)

  let res = yield call(() => getLanguage(language))

  yield put({
    type: loggerActions.CREATE_LOG,
    msg: 'Resources Loaded',
    data: 'After this one home page should load',
  })

  yield put({
    type: actions.SET_RESOURCES,
    data: res,
  })

  yield put({ type: appActions.API_CALL_END })
}

export default function* rootSaga() {
  yield all([yield takeLatest(actions.LOAD_RESOURCES, loadResources)])
}
