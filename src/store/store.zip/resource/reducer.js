import actions from './action';

const initialState = {
	resources: {}
}

export default function appReducer(state = initialState, action) {
	switch(action.type) {
		case actions.SET_RESOURCES:
			return ({
				...state, 
				resources: action.data
			})
		default:
			return state;
	}
}
