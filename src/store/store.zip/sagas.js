import { all } from 'redux-saga/effects';

import resourceSaga from './resource/saga';
import operationSaga from './operation/saga';
import loggerSaga from './logger/saga';

export default function* rootSaga(getState) {
	yield all([
		resourceSaga(),
		operationSaga(),
		loggerSaga()
	]);
}
