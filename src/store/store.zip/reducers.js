import App from './app/reducer';
import Resource from './resource/reducer';
import Operation from './operation/reducer';

export default {
	App,
	Resource,
	Operation
}
