// import {Platform, Dimensions, StatusBar} from 'react-native';

// import actions from './action';
// var {height, width} = Dimensions.get('window');

const initialState = {
	apiProcessing: false,
	route: 'home',
	routeParam: {}
}

export default function appReducer(state = initialState, action) {
	switch (action.type) {
		default:
			return state;
	}
}
