const actions = {
	API_CALL_START: 'API_CALL_START',
	API_CALL_END: 'API_CALL_END',
	APP_NAVIGATION: 'APP_NAVIGATION',

	navigate: (route, params) => (dispatch, getState) => {
		dispatch({ type: actions.APP_NAVIGATION, route, params })
	}
}

export default actions;
