import { all, takeLatest, put, call } from 'redux-saga/effects'

import actions from './action'
import appActions from '../app/action'
import loggerActions from '../logger/action'
import {
  getLanguage as apiGetLanguage,
  registerDevice as apiRegisterDevice,
  getDevice as apiGetDevice,
  getDeviceCurriculum as apiGetDeviceCurriculum,
  getDeviceCurriculumContent as apiGetDeviceCurriculumContent,
  updateQuizAnswer,
  updateTopic,
  addActivity,
  updateLanguage,
} from '../../services/api'
import resourceActions from './../resource/action'

export function* registerDevice() {
  // try {
  // 	yield (AsyncStorage.removeItem('deviceid'));
  // } catch (e) {
  // 	console.log(e);
  // }

  // let e_id = yield (AsyncStorage.getItem('deviceid'));

  console.log('*****************************')

  let e_id = ''

  console.log('Register Device Saga ', e_id)
  yield put({
    type: loggerActions.CREATE_LOG,
    msg: 'Register Device Check ',
    data: e_id,
  })

  if (!e_id) {
    yield put({
      type: loggerActions.CREATE_LOG,
      msg: 'Collect phone info',
      data: {},
    })

    console.log(
      'under new devce id generation',
      'Constants',
      'Constants.platform'
    )
    let is_iseries = !!'TBD' //Constants.platform.ios
    let model = 'TBD', //
      // Constants.platform.ios.model:
      // 	(Constants.platform.android.model || 'android');
      os = 'TBD',
      // Constants.platform.ios.systemVersion :
      // Constants.platform.android.versionCode;
      type = is_iseries ? 'iphone' : 'android'

    let params = {
      model: 'TBD', //Constants.deviceName
      type: type,
      os: '' + os,
    }

    yield put({
      type: loggerActions.CREATE_LOG,
      msg: 'Register Device Api call',
      data: params,
    })

    console.log(params)

    let res = yield call(() => apiRegisterDevice(params))

    console.log('Device register response', res, params, model)
    yield put({
      type: loggerActions.CREATE_LOG,
      msg: 'Register Device Api response',
      data: res,
    })

    if (res && !res.error && res.id) {
      yield localStorage.setItem('deviceid', res.id)
      yield localStorage.setItem('language', 'en')
      yield put({
        type: actions.SET_DEVICE_LANGUAGE,
        data: 'en',
      })
      yield put({
        type: actions.SET_DEVICE_ID,
        device_id: res.id,
      })
    }
  } else {
    yield put({
      type: actions.SET_DEVICE_LANGUAGE,
      data: 'en',
    })
    yield put({
      type: actions.SET_DEVICE_ID,
      device_id: e_id,
    })
  }
}

export function* getDeviceCurriculum() {
  let language = yield localStorage.getItem('language')
  console.log('operation saga: getDeviceCurriculum language: ' + language)
  let res

  res = yield call(() => apiGetDeviceCurriculum('deviceId', language)) // need to replace deviceId

  if (res && !res.error && res.curriculum) {
    const curriculum = Object.keys(res.curriculum.topics).map(
      (key) => res.curriculum.topics[key]
    )

    let completedItems = 0
    let totalItems = 0
    let congrats = ''
    let progress = []
    let showCongrats = false
    let congratsTopicId = null
    let topicOrder = 0

    curriculum.forEach(function (topic) {
      //console.log("TOPICSAGA")
      //console.log(topic)

      /*
			Figure out progress for each topic
			 */
      completedItems = 0
      totalItems = 0
      if (topic.contents.length > 0) {
        totalItems = topic.contents.length
        Object.keys(topic.contents).map((key) => {
          if (topic.contents[key].complete) {
            //console.log("completed key: " + key + " - " + topic.contents[key].name)
            completedItems = completedItems + 1
          }
        })
      }
      //handle scenario where we have no task at all for the user to complete in the topic.
      if (totalItems === 0) {
        completedItems = 1
        totalItems = 1
      }
      topic.progress = Math.round((completedItems / totalItems) * 100)
      progress.push(topic.progress)

      if (topic.showCongrats) {
        //alert('showCongrats topic is true!!: ' + topic.id);
        congratsTopicId = topic.id
        topicOrder = topic.order
        congrats = topic.congrats
        showCongrats = true
      }
    })

    //figure out whether we need to show a congrats

    //alert('getDeviceCurriculum called. topic[0].progress: ' + curriculum[0].progress);
    //progress = 0;
    //progress = (completedItems / totalItems ) * 100
    /* console.log("completedItems")
		console.log(completedItems)
		console.log("totalItems")
		console.log(totalItems)
		console.log("progress")
		console.log(progress)
		console.log("congrats")
		console.log(congrats) */

    yield put({
      type: actions.SET_DEVICE_CURRICULUM,
      completeditems: completedItems,
      totalitems: totalItems,
      progress: progress,
      congrats: congrats,
      showCongrats: showCongrats,
      congratsTopicId: congratsTopicId,
      topicOrder: topicOrder,
      data: curriculum || [],
    })
  }
}
export function* getDeviceCurriculumContent({ content_id }) {
  let language = yield localStorage.getItem('language')
  console.log(
    'operation saga: getDeviceCurriculumContent language: ' + language
  )

  let res
  res = yield call(
    () => apiGetDeviceCurriculumContent('deviceId', content_id, language) // need to replace deviceId
  )

  if (res && !res.error && res.content) {
    yield put({
      type: actions.SET_DEVICE_CURRICULUM_CONTENT,
      quizzes: res.content.quizzes,
      screens: res.content.data.screens,
    })
  }
}
export function* quizAnswerSubmit({
  quiz_id,
  complete,
  quiz_data,
  selected_answer,
  progress,
  topicOrder,
}) {
  let data
  data = {
    complete: complete,
    data: quiz_data,
  }
  let params = {
    topicOrder: topicOrder,
  }
  console.log('Data')
  console.log(data)
  let res = yield call(() => updateQuizAnswer('deviceId', quiz_id, data))

  if (res && !res.errors) {
    yield put({
      type: actions.SET_QUIZ_ANSWER_RESULT,
      data: res,
      selected_answer: selected_answer,
      progress: progress,
      topicOrder: topicOrder,
    })
    yield put({
      type: appActions.APP_NAVIGATION,
      route: 'dayanswers',
      params: params,
    })
  }
}

export function* updateTopicSubmit({ topic_id, showCongrats }) {
  let data
  data = {
    showCongrats: showCongrats,
  }

  let res = yield call(() => updateTopic('deviceId', topic_id, data))

  if (res && !res.errors) {
    yield put({
      type: appActions.APP_NAVIGATION,
      route: 'home',
    })
  }
}

export function* logAvtivityDuration({ duration, action, objectId, data }) {
  let body = {
    duration,
    action,
    objectId,
    data,
  }
  let res = yield call(() => addActivity('deviceId', body))
  console.log('Duration Logging ', body)
  if (res && res.errors) {
    yield put({
      type: appActions.APP_NAVIGATION,
      route: 'home',
    })
  }
}

export function* getDeviceLanguage() {
  console.log('operation saga: getDeviceLanguage was called')
  let currentLanguage = 'en'

  let res = yield call(() => apiGetDevice('deviceId'))

  if (
    typeof res !== 'undefined' &&
    typeof res.device !== 'undefined' &&
    !res.error &&
    typeof res.device.summary !== 'undefined' &&
    typeof res.device.summary.language !== 'undefined'
  ) {
    console.log(
      'operation saga: getDeviceLanguage LANGUAGE retrieved from server: ' +
        res.device.summary.language
    )
    yield put({
      type: actions.SET_DEVICE_LANGUAGE,
      data: res.device.summary.language,
    })

    currentLanguage = res.device.summary.language
    yield localStorage.setItem('language', currentLanguage)
    yield put({ type: appActions.API_CALL_START })
    console.log(
      'operation saga: getDeviceResources with language: ' + currentLanguage
    )

    let resLanguage = yield call(() => apiGetLanguage(currentLanguage))

    yield put({
      type: loggerActions.CREATE_LOG,
      msg: 'Resources Loaded',
      data: 'After this one home page should load',
    })

    yield put({
      type: resourceActions.SET_RESOURCES,
      data: resLanguage,
    })

    yield put({ type: appActions.API_CALL_END })
  } else {
    //we didn't get a device language!
    console.log('operation saga: getDeviceLanguage NO DEVICE LANGUAGE.')
    let resLanguage = yield call(() => apiGetLanguage(currentLanguage))

    yield put({
      type: loggerActions.CREATE_LOG,
      msg: 'Resources Loaded',
      data: 'After this one home page should load',
    })

    yield put({
      type: resourceActions.SET_RESOURCES,
      data: resLanguage,
    })

    yield put({ type: appActions.API_CALL_END })
  }
}

export function* registerLanguage({ language }) {
  console.log('Operation SAGA Register Language Called with: ' + language)

  let currentLanguage = 'en'
  if (language) {
    currentLanguage = language
  }

  let e_id = yield localStorage.getItem('deviceid')

  console.log('Register Language Saga DEVICE ID: ', e_id)
  yield put({
    type: loggerActions.CREATE_LOG,
    msg: 'Register Device Language ',
    data: e_id,
  })

  if (e_id) {
    let params = {
      language: currentLanguage,
    }

    yield put({
      type: loggerActions.CREATE_LOG,
      msg: 'Register Device Language Api call',
      data: params,
    })

    console.log(params)

    console.log(
      '------------------- Register Language Saga DEVICE ID: ',
      e_id,
      ' --------------------------------'
    )

    let res = yield call(() => updateLanguage('deviceId', params))

    yield put({
      type: loggerActions.CREATE_LOG,
      msg: 'Register Device Language Api response',
      data: res,
    })

    if (
      typeof res !== 'undefined' &&
      typeof res.device !== 'undefined' &&
      !res.error &&
      typeof res.device.summary !== 'undefined' &&
      typeof res.device.summary.language !== 'undefined'
    ) {
      console.log(
        'Device Register Device Language set language: ' + currentLanguage
      )
      console.log(
        '------------------- Register Language Saga DEVICE ID: ',
        e_id,
        ' RESPONSE set language: ',
        currentLanguage,
        ' --------------------------------'
      )
      yield localStorage.setItem('language', currentLanguage)
      yield put({
        type: actions.SET_DEVICE_LANGUAGE,
        data: currentLanguage,
      })

      //Update resources for the application!
      let resLanguage = yield call(() => apiGetLanguage(currentLanguage))

      yield put({
        type: loggerActions.CREATE_LOG,
        msg: 'Resources Loaded',
        data: 'After this one home page should load',
      })

      console.log(
        '------------------- Register Language Saga DEVICE ID: ',
        e_id,
        ' RESOURCE RESPONSE: ',
        JSON.stringify(resLanguage),
        ' --------------------------------'
      )

      yield put({
        type: resourceActions.SET_RESOURCES,
        data: resLanguage,
      })

      console.log('operation saga: getDeviceCurriculum language: ' + language)
      let res

      let resDeviceCurriculum = yield call(() =>
        apiGetDeviceCurriculum('deviceId', language)
      )

      if (
        resDeviceCurriculum &&
        !resDeviceCurriculum.error &&
        resDeviceCurriculum.curriculum
      ) {
        const curriculum = Object.keys(
          resDeviceCurriculum.curriculum.topics
        ).map((key) => resDeviceCurriculum.curriculum.topics[key])

        let completedItems = 0
        let totalItems = 0
        let congrats = ''
        let progress = []
        let showCongrats = false
        let congratsTopicId = null
        let topicOrder = 0

        curriculum.forEach(function (topic) {
          //console.log("TOPICSAGA")
          //console.log(topic)

          /*
					Figure out progress for each topic
					 */
          completedItems = 0
          totalItems = 0
          if (topic.contents.length > 0) {
            totalItems = topic.contents.length
            Object.keys(topic.contents).map((key) => {
              if (topic.contents[key].complete) {
                //console.log("completed key: " + key + " - " + topic.contents[key].name)
                completedItems = completedItems + 1
              }
            })
          }
          //handle scenario where we have no task at all for the user to complete in the topic.
          if (totalItems === 0) {
            completedItems = 1
            totalItems = 1
          }
          topic.progress = Math.round((completedItems / totalItems) * 100)
          progress.push(topic.progress)

          if (topic.showCongrats) {
            //alert('showCongrats topic is true!!: ' + topic.id);
            congratsTopicId = topic.id
            topicOrder = topic.order
            congrats = topic.congrats
            showCongrats = true
          }
        })

        //figure out whether we need to show a congrats

        //alert('getDeviceCurriculum called. topic[0].progress: ' + curriculum[0].progress);
        //progress = 0;
        //progress = (completedItems / totalItems ) * 100
        /* console.log("completedItems")
				console.log(completedItems)
				console.log("totalItems")
				console.log(totalItems)
				console.log("progress")
				console.log(progress)
				console.log("congrats")
				console.log(congrats) */

        yield put({
          type: actions.SET_DEVICE_CURRICULUM,
          completeditems: completedItems,
          totalitems: totalItems,
          progress: progress,
          congrats: congrats,
          showCongrats: showCongrats,
          congratsTopicId: congratsTopicId,
          topicOrder: topicOrder,
          data: curriculum || [],
        })
      }
    }
  } else {
    yield put({
      type: actions.SET_DEVICE_LANGUAGE,
      data: currentLanguage,
    })
  }
}

export default function* rootSaga() {
  yield all([
    // yield takeLatest(actions.REGISTER_DEVICE, registerDevice),
    yield takeLatest(actions.REGISTER_LANGUAGE, registerLanguage),
    yield takeLatest(actions.GET_DEVICE_LANGUAGE, getDeviceLanguage),
    yield takeLatest(actions.GET_DEVICE_CURRICULUM, getDeviceCurriculum),
    yield takeLatest(
      actions.GET_DEVICE_CURRICULUM_CONTENT,
      getDeviceCurriculumContent
    ),
    yield takeLatest(actions.QUIZ_ANSWER_RESULT, quizAnswerSubmit),
    yield takeLatest(actions.UPDATE_TOPIC_RESULT, updateTopicSubmit),
    yield takeLatest(actions.LOG_ACTIVITY_DURATION, logAvtivityDuration),
  ])
}
