import actions from './action';

const initialState = {
	device_id: '',
	language: 'en',
	total_items: 0,
	completed_items: 0,
	showCongrats: false,
	congratsTopicId: null,
	topicOrder: 0,
	congrats: [],
	cirriculum_result: [],
	quiz_result: [],
	content_result: {},
	quizzes: {}
}

export default function appReducer(state = initialState, action) {
	switch(action.type) {
		case actions.SET_DEVICE_ID:
			return ({
				...state,
				device_id: action.device_id
			})
		case actions.SET_DEVICE_LANGUAGE:
			console.log('operation reducer: SET_DEVICE_LANGUAGE: ' + action.data);
			return ({
				...state,
				language: action.data
			})
		case actions.SET_DEVICE_CURRICULUM:
			return ({
				...state,
				completed_items: action.completeditems,
				total_items: action.totalitems, 
				progress: action.progress,
				congrats: action.congrats,
				showCongrats: action.showCongrats,
				congratsTopicId: action.congratsTopicId,
				topicOrder: action.topicOrder,
				cirriculum_result: action.data
			})
		case actions.SET_DEVICE_CURRICULUM_CONTENT: 
			return ({
				...state, 
				content_result: action.screens, 
				quizzes: action.quizzes
			})
		case actions.SET_QUIZ_ANSWER_RESULT:
			return ({
				...state, 
				quiz_result: action.data,
				selected_answer: action.selected_answer,
				progress: action.progress,
				topicOrder: action.topicOrder
			})
		default:
			return state;
	}
}
