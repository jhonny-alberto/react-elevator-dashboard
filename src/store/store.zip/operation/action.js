const actions = {
	REGISTER_DEVICE: 'REGISTER_DEVICE',
	GET_DEVICE_LANGUAGE: 'GET_DEVICE_LANGUAGE',
	SET_DEVICE_ID: 'SET_DEVICE_ID',
	REGISTER_LANGUAGE: 'REGISTER_LANGUAGE',
	SET_DEVICE_LANGUAGE: 'SET_DEVICE_LANGUAGE',
	GET_DEVICE_CURRICULUM: 'GET_DEVICE_CURRICULUM',
	SET_DEVICE_CURRICULUM: 'SET_DEVICE_CURRICULUM',
	GET_DEVICE_CURRICULUM_CONTENT: 'GET_DEVICE_CURRICULUM_CONTENT',
	SET_DEVICE_CURRICULUM_CONTENT: 'SET_DEVICE_CURRICULUM_CONTENT',
	UPDATE_TOPIC_RESULT:'UPDATE_TOPIC_RESULT',
	QUIZ_ANSWER_RESULT: 'QUIZ_ANSWER_RESULT',
	SET_QUIZ_ANSWER_RESULT: 'SET_QUIZ_ANSWER_RESULT',
	LOG_ACTIVITY_DURATION: 'LOG_ACTIVITY_DURATION',

	logAvtivityDuration: ({duration, action, objectId, data}) => (dispatch) => {
		dispatch({
			type: actions.LOG_ACTIVITY_DURATION,
			duration, action, objectId, data
		})
	},

	registerDevice: () => (dispatch, getState) => {
		dispatch({ type: actions.REGISTER_DEVICE }); 
	},

	getDeviceLanguage: () => (dispatch,getState) => {
		console.log('Operation Action Get Device Language Called');
		dispatch({ type: actions.GET_DEVICE_LANGUAGE })
	},

	registerLanguage: (language) => (dispatch, getState) => {
		console.log('Operation Action Register Language Called with: ' + language);
		dispatch({ type: actions.REGISTER_LANGUAGE, language });
	},

	getDeviceCurriculum: () => (dispatch, getState) => {
		dispatch({ type: actions.GET_DEVICE_CURRICULUM }); 
	},

	getDeviceCurriculumContent: (content_id) => (dispatch, getState) => {
		dispatch({ type: actions.GET_DEVICE_CURRICULUM_CONTENT, content_id }); 
	},

	quizAnswerSubmit: (quiz_id, complete, quiz_data, selected_answer, progress,topicOrder) => (dispatch, getState) => {
		dispatch({ type: actions.QUIZ_ANSWER_RESULT, quiz_id, complete, quiz_data, selected_answer, progress,topicOrder });
	},

	updateTopicSubmit: (topic_id, showCongrats) => (dispatch,getState) => {
		dispatch({ type: actions.UPDATE_TOPIC_RESULT, topic_id, showCongrats});
	}

}

export default actions;
